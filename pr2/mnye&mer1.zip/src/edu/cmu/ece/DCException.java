package edu.cmu.ece;

/**
 * Exception that is thrown when we must disconnect.
 * 
 * @author Michaels
 * 
 */
public class DCException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
